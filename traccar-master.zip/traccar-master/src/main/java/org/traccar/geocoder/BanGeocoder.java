/*
 * Copyright 2018 Olivier Girondel (olivier@biniou.info)
 * Copyright 2018 - 2025 Anton Tananaev (anton@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.geocoder;


import jakarta.json.JsonObject;
import jakarta.ws.rs.client.Client;

/**
 * [API documentation](https://adresse.data.gouv.fr/api)
 */
public class BanGeocoder extends GeocodeJsonGeocoder {

    public BanGeocoder(Client client, int cacheSize, AddressFormat addressFormat) {
        super(client, "https://data.geopf.fr/geocodage/reverse", null, null, cacheSize, addressFormat);
    }

    @Override
    public Address parseAddress(JsonObject json) {
        Address address = super.parseAddress(json);
        if (address != null) {
            address.setCountry("FR");
        }
        return address;
    }

}
