/*
 * Copyright 2017 - 2026 Anton Tananaev (anton@traccar.org)
 * Copyright 2017 Andrey Kunitsyn (andrey@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.api;

import org.traccar.model.BaseModel;
import org.traccar.model.User;
import org.traccar.storage.StorageException;
import org.traccar.storage.query.Columns;
import org.traccar.storage.query.Condition;
import org.traccar.storage.query.Order;
import org.traccar.storage.query.Request;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.QueryParam;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

public class SimpleObjectResource<T extends BaseModel> extends BaseObjectResource<T> {

    private final String sortField;
    private final List<String> searchColumns;

    public SimpleObjectResource(Class<T> baseClass, String sortField, List<String> searchColumns) {
        super(baseClass);
        this.sortField = sortField;
        this.searchColumns = searchColumns;
    }

    @GET
    public Stream<T> get(
            @QueryParam("all") boolean all, @QueryParam("userId") long userId,
            @QueryParam("excludeAttributes") boolean excludeAttributes,
            @QueryParam("limit") int limit, @QueryParam("offset") int offset,
            @QueryParam("keyword") String keyword) throws StorageException {

        var conditions = new LinkedList<Condition>();

        if (all) {
            if (permissionsService.notAdmin(getUserId())) {
                conditions.add(new Condition.Permission(User.class, getUserId(), baseClass));
            }
        } else {
            if (userId == 0) {
                userId = getUserId();
            } else {
                permissionsService.checkUser(getUserId(), userId);
            }
            conditions.add(new Condition.Permission(User.class, userId, baseClass));
        }

        if (keyword != null && !keyword.isEmpty()) {
            conditions.add(new Condition.Contains(searchColumns, keyword));
        }

        Columns columns = excludeAttributes ? new Columns.Exclude("attributes") : new Columns.All();
        Order order = new Order(sortField != null ? sortField : "id", false, limit, offset);
        return storage.getObjectsStream(baseClass, new Request(columns, Condition.merge(conditions), order));
    }

}
